"""Bounded model adapters; clients with unenforced caps remain a separate track."""

from __future__ import annotations

import hashlib
import json
import math
import re
import time
import urllib.error
import urllib.parse
import urllib.request


def _load_mlx(config):
    from mlx_lm import load
    return load(config['model'], revision=config.get('revision'))


def _mlx_stream(model, tokenizer, tokens, max_tokens):
    from mlx_lm import stream_generate
    from mlx_lm.sample_utils import make_sampler
    return stream_generate(model, tokenizer, prompt=tokens, max_tokens=max_tokens,
                           sampler=make_sampler(temp=0.0))


def _new_native(config, timeout):
    if config['type'] == 'claude_code':
        from temporal_bridge.claude_backend import ClaudeCodeBackend
        return ClaudeCodeBackend(model=config['model'], effort=config.get('effort', 'high'),
                                 profile=config.get('profile', 'startup'), timeout_s=timeout)
    from temporal_bridge.codex_backend import CodexBackend
    return CodexBackend(model=config['model'], effort=config.get('effort', 'high'), timeout_s=timeout)


def _validate(messages, max_tokens, timeout_s, request_id):
    if (not isinstance(messages, list) or not messages or
            any(not isinstance(m, dict) or m.get('role') not in ('system', 'user', 'assistant')
                or not isinstance(m.get('content'), str) or not m['content'].strip() for m in messages)):
        raise ValueError('messages must contain nonempty system, user, or assistant text')
    if isinstance(max_tokens, bool) or not isinstance(max_tokens, int) or max_tokens <= 0:
        raise ValueError('max_tokens must be a positive integer')
    if (isinstance(timeout_s, bool) or not isinstance(timeout_s, (int, float))
            or not math.isfinite(timeout_s) or timeout_s <= 0):
        raise ValueError('timeout_s must be positive and finite')
    if not isinstance(request_id, str) or not re.fullmatch(r'[A-Za-z0-9._-]{1,128}', request_id):
        raise ValueError('request_id must be a safe explicit identifier')


def _number(value):
    return value if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value >= 0 else None


def _redact(value, secret):
    if isinstance(value, str):
        return value.replace(secret, '[REDACTED]') if secret else value
    if isinstance(value, dict):
        return {k: _redact(v, secret) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v, secret) for v in value]
    return value


def _separate_thinking(text):
    reasoning = []
    def remove(match):
        reasoning.append(match.group(1))
        return ''
    visible = re.sub(r'<think>(.*?)</think>', remove, text, flags=re.DOTALL)
    if '<think>' in visible:
        visible, _, partial = visible.partition('<think>')
        reasoning.append(partial)
    return visible, '\n'.join(reasoning)


def _visible_so_far(text):
    visible, _ = _separate_thinking(text)
    # A tag may be split across streaming chunks; do not count its prefix as output.
    for length in range(min(len('<think>') - 1, len(visible)), 0, -1):
        if visible.endswith('<think>'[:length]):
            return visible[:-length]
    return visible


def _safe_request_policy(body):
    policy = {'temperature': body['temperature'], 'max_tokens': body['max_tokens']}
    if 'seed' in body:
        policy['seed'] = body['seed']
    reasoning = body.get('reasoning')
    if isinstance(reasoning, dict):
        policy['reasoning'] = {key: reasoning[key] for key in ('enabled', 'effort', 'max_tokens', 'exclude')
                               if key in reasoning and isinstance(reasoning[key], (str, int, float, bool))}
    provider = body.get('provider')
    if isinstance(provider, dict):
        selected = {key: provider[key] for key in ('order', 'only', 'ignore', 'allow_fallbacks',
                                                    'require_parameters', 'quantizations', 'data_collection')
                    if key in provider}
        price = provider.get('max_price')
        if isinstance(price, dict):
            selected['max_price'] = {key: price[key] for key in ('prompt', 'completion', 'image', 'request')
                                     if key in price and _number(price[key]) is not None}
        policy['provider'] = selected
    return policy


class Adapter:
    def __init__(self, config):
        if not isinstance(config, dict) or config.get('type') not in {'mlx', 'http', 'claude_code', 'codex'}:
            raise ValueError('unknown adapter type')
        if not isinstance(config.get('model'), str) or not config['model']:
            raise ValueError('model is required')
        allowed = config.get('allowed_resolved_models', [])
        if not isinstance(allowed, list) or any(not isinstance(x, str) or not x for x in allowed):
            raise ValueError('allowed resolved models must be explicit strings')
        self._secret = config.get('api_key')
        if self._secret is not None and (not isinstance(self._secret, str) or not self._secret):
            raise ValueError('api key must be nonempty when supplied')
        self._config = {k: v for k, v in config.items() if k != 'api_key'}
        self._model = None
        self._tokenizer = None
        self._native = None
        self._native_timeout = None
        kind = config['type']
        self.capabilities = {'hard_token_cap': True if kind == 'mlx' else
                             (False if kind in ('claude_code', 'codex') else config.get('hard_token_cap')),
                             'sampling_seed': False if kind in ('mlx', 'claude_code', 'codex') else config.get('sampling_seed'),
                             'streaming': True, 'thinking': config.get('thinking_supported')}
        self.metadata = {'type': kind, 'provider': config.get('provider', kind),
                         'requested_model': config.get('model_id', config['model']),
                         'revision': config.get('revision'), 'quantization': config.get('quantization'),
                         'capabilities': dict(self.capabilities)}
        if kind == 'http':
            url = config.get('endpoint')
            if not isinstance(url, str):
                raise ValueError('HTTP endpoint required')
            parsed = urllib.parse.urlsplit(url)
            if (parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or
                    parsed.password or parsed.query or parsed.fragment or
                    (parsed.scheme == 'http' and parsed.hostname not in ('127.0.0.1', 'localhost', '::1'))):
                raise ValueError('endpoint must be HTTPS or loopback HTTP without credentials or query')
            self._endpoint = url.rstrip('/')
            self.metadata['endpoint'] = _redact(self._endpoint, self._secret)

    def _base(self, request_id):
        return {'text': '', 'raw_text': '', 'reasoning': '', 'requested_model': self.metadata['requested_model'],
                'resolved_model': None, 'elapsed_s': None, 'first_visible_s': None,
                'usage': {'input_tokens': None, 'output_tokens': None, 'total_tokens': None, 'cost_usd': None},
                'finish_reason': None, 'status': 'error', 'error': None,
                'capabilities': dict(self.capabilities), 'provider': self.metadata['provider'],
                'raw_safe_metadata': {'request_id': request_id}}

    def _identity(self, result):
        resolved = result['resolved_model']
        allowed = [self.metadata['requested_model'], *self._config.get('allowed_resolved_models', [])]
        if resolved is None:
            result['raw_safe_metadata']['identity_validation'] = 'unavailable'
        elif resolved not in allowed:
            result['status'] = 'identity_mismatch'
            result['error'] = {'code': 'resolved_model_not_allowed'}
            result['raw_safe_metadata']['identity_validation'] = 'mismatch'
        else:
            result['raw_safe_metadata']['identity_validation'] = 'matched'

    def generate(self, messages, *, max_tokens, timeout_s, request_id):
        _validate(messages, max_tokens, timeout_s, request_id)
        started = time.monotonic()
        result = self._base(request_id)
        result['raw_safe_metadata']['messages_sha256'] = hashlib.sha256(
            json.dumps(messages, sort_keys=True, ensure_ascii=False, separators=(',', ':')).encode()).hexdigest()
        result['raw_safe_metadata']['requested_max_tokens'] = max_tokens
        result['raw_safe_metadata']['requested_thinking'] = self._config.get('thinking')
        result['raw_safe_metadata']['retry_policy'] = ('native_client_internal_unknown' if self._config['type']
                                                       in ('claude_code', 'codex') else 'none_by_adapter')
        try:
            if self._config['type'] == 'mlx':
                self._generate_mlx(result, messages, max_tokens, timeout_s, started)
            elif self._config['type'] == 'http':
                self._generate_http(result, messages, max_tokens, timeout_s, started, request_id)
            else:
                self._generate_native(result, messages, max_tokens, timeout_s, started)
            if result['status'] == 'ok' and self._config['type'] != 'mlx':
                self._identity(result)
        except TimeoutError:
            result['status'], result['error'] = 'timeout', {'code': 'timeout'}
        except urllib.error.HTTPError as exc:
            result['status'], result['error'] = 'http_error', {'code': 'http_error', 'http_status': exc.code}
        except Exception as exc:  # noqa: BLE001 - provider messages may contain credentials
            # Provider and OS exceptions can contain credentials; retain only the type.
            result['status'], result['error'] = 'error', {'code': type(exc).__name__}
        result['elapsed_s'] = time.monotonic() - started
        return _redact(result, self._secret)

    def _generate_mlx(self, result, messages, max_tokens, timeout_s, started):
        if self._model is None:
            self._model, self._tokenizer = _load_mlx(self._config)
        template = getattr(self._tokenizer, 'chat_template', None)
        template_text = template if isinstance(template, str) else None
        support = 'enable_thinking' in template_text if template_text else None
        kwargs = {'tokenize': True, 'add_generation_prompt': True}
        if support and self._config.get('thinking') is not None:
            kwargs['enable_thinking'] = self._config['thinking']
        tokens = self._tokenizer.apply_chat_template(messages, **kwargs)
        result['raw_safe_metadata'].update({'chat_template_sha256': hashlib.sha256(template_text.encode()).hexdigest()
                                            if template_text else None,
                                            'thinking_template_support': support,
                                            'generation_temperature': 0.0,
                                            'timeout_enforcement': 'checked_between_stream_events'})
        text = []
        for event in _mlx_stream(self._model, self._tokenizer, tokens, max_tokens):
            if time.monotonic() - started > timeout_s:
                raise TimeoutError
            text.append(event.text)
            result['raw_text'] = ''.join(text)
            result['text'], result['reasoning'] = _separate_thinking(result['raw_text'])
            if result['first_visible_s'] is None and _visible_so_far(result['raw_text']):
                result['first_visible_s'] = time.monotonic() - started
            result['usage']['input_tokens'] = _number(event.prompt_tokens)
            result['usage']['output_tokens'] = _number(event.generation_tokens)
            result['finish_reason'] = event.finish_reason or result['finish_reason']
        result['raw_text'] = ''.join(text)
        result['text'], result['reasoning'] = _separate_thinking(result['raw_text'])
        if result['usage']['input_tokens'] is not None and result['usage']['output_tokens'] is not None:
            result['usage']['total_tokens'] = result['usage']['input_tokens'] + result['usage']['output_tokens']
        result['raw_safe_metadata']['identity_validation'] = 'caller_supplied_local_identity'
        result['raw_safe_metadata']['local_model_path'] = self._config['model']
        result['status'] = 'ok' if result['finish_reason'] else 'incomplete_stream'

    def _generate_http(self, result, messages, max_tokens, timeout_s, started, request_id):
        body = dict(self._config.get('extra_body', {}))
        if any(k in body for k in ('model', 'messages', 'max_tokens', 'stream', 'temperature')):
            raise ValueError('extra_body cannot override required request fields')
        body.update({'model': self._config['model'], 'messages': messages, 'max_tokens': max_tokens,
                     'temperature': 0, 'stream': True})
        if self._config.get('seed') is not None:
            body['seed'] = self._config['seed']
        if self._config.get('stream_options') is not None:
            body['stream_options'] = self._config['stream_options']
        result['raw_safe_metadata']['request_policy'] = _safe_request_policy(body)
        headers = {'Content-Type': 'application/json', 'Accept': 'text/event-stream', 'X-Request-ID': request_id}
        if self._secret:
            headers['Authorization'] = 'Bearer ' + self._secret
        endpoint = self._endpoint if self._endpoint.endswith('/chat/completions') else self._endpoint + '/chat/completions'
        request = urllib.request.Request(endpoint, data=json.dumps(body).encode(), headers=headers, method='POST')
        result['raw_safe_metadata']['timeout_enforcement'] = 'socket_timeout_and_checked_between_events'
        result['raw_safe_metadata']['generation_temperature'] = 0
        text, reasoning, models, done = [], [], set(), False
        with urllib.request.urlopen(request, timeout=timeout_s) as response:
            for line in response:
                if time.monotonic() - started > timeout_s:
                    raise TimeoutError
                if not line.startswith(b'data:'):
                    continue
                data = line[5:].strip()
                if data == b'[DONE]':
                    done = True
                    break
                event = json.loads(data)
                if event.get('error'):
                    result['status'], result['error'] = 'provider_error', {'code': 'provider_error'}
                    return
                if isinstance(event.get('model'), str):
                    models.add(event['model'])
                for choice in event.get('choices') or []:
                    if choice.get('index', 0) != 0:
                        continue
                    delta = choice.get('delta') or {}
                    segment = delta.get('content')
                    if isinstance(segment, str) and segment:
                        text.append(segment)
                        result['raw_text'] = ''.join(text)
                        result['text'], tagged = _separate_thinking(result['raw_text'])
                        result['reasoning'] = ''.join(reasoning) + tagged
                        if result['first_visible_s'] is None and _visible_so_far(result['raw_text']):
                            result['first_visible_s'] = time.monotonic() - started
                    for key in ('reasoning', 'reasoning_content'):
                        if isinstance(delta.get(key), str):
                            reasoning.append(delta[key])
                            result['reasoning'] = ''.join(reasoning) + _separate_thinking(result['raw_text'])[1]
                    if choice.get('finish_reason') is not None:
                        result['finish_reason'] = choice['finish_reason']
                if isinstance(event.get('usage'), dict):
                    usage = event['usage']
                    result['usage'] = {'input_tokens': _number(usage.get('prompt_tokens')),
                                       'output_tokens': _number(usage.get('completion_tokens')),
                                       'total_tokens': _number(usage.get('total_tokens')),
                                       'cost_usd': _number(usage.get('cost'))}
        result['raw_text'] = ''.join(text)
        result['text'], tagged = _separate_thinking(result['raw_text'])
        result['reasoning'] = ''.join(reasoning) + tagged
        result['raw_safe_metadata']['stream_done'] = done
        result['resolved_model'] = next(iter(models)) if len(models) == 1 else None
        if len(models) > 1:
            result['status'], result['error'] = 'identity_mismatch', {'code': 'multiple_resolved_models'}
        else:
            result['status'] = 'ok' if result['finish_reason'] and done else 'incomplete_stream'

    def _generate_native(self, result, messages, max_tokens, timeout_s, started):
        if len(messages) != 1 or messages[0]['role'] != 'user':
            result['status'], result['error'] = 'unsupported_messages', {'code': 'native_requires_one_user_message'}
            return
        if self._native is None or self._native_timeout != timeout_s:
            if self._native is not None:
                self.close()
            self._native = _new_native(self._config, timeout_s)
            self._native_timeout = timeout_s
        final = {}
        def emit(event, **data):
            if event == 'first_token' and result['first_visible_s'] is None:
                result['first_visible_s'] = _number(data.get('elapsed_s'))
                if result['first_visible_s'] is None:
                    result['first_visible_s'] = time.monotonic() - started
            if event == 'delta' and isinstance(data.get('text'), str):
                result['raw_text'] += data['text']
                result['text'], result['reasoning'] = _separate_thinking(result['raw_text'])
            if event == 'result':
                final.update(data)
        self._native.generate(messages[0]['content'], max_tokens, emit)
        result['text'] = final.get('text', '')
        result['raw_text'] = result['text']
        result['resolved_model'] = final.get('resolved_model') or final.get('model')
        result['finish_reason'] = final.get('finish_reason')
        result['usage']['input_tokens'] = _number(final.get('input_tokens_total', final.get('input_tokens')))
        result['usage']['output_tokens'] = _number(final.get('output_tokens'))
        result['usage']['cost_usd'] = _number(final.get('estimated_cost_usd'))
        if result['usage']['input_tokens'] is not None and result['usage']['output_tokens'] is not None:
            result['usage']['total_tokens'] = result['usage']['input_tokens'] + result['usage']['output_tokens']
        result['raw_safe_metadata']['cost_is_estimate'] = final.get('cost_is_estimate')
        result['raw_safe_metadata']['timeout_enforcement'] = 'native_client'
        result['status'] = 'ok' if isinstance(result['text'], str) and result['text'] else 'incomplete_stream'

    def close(self):
        if self._native is not None:
            self._native.close()
            self._native = None
        self._model = None
        self._tokenizer = None


def create_adapter(config):
    return Adapter(config)
