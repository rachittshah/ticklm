# Adapter source recovery

Recovered on 3 November 2026 by replaying the original agent's successful,
single-file `adapters.py` patches into an isolated temporary file. No run
manifest or original source file was changed. Every directory below is named
by the SHA-256 of its `adapters.py` contents.

| Source state | SHA-256 | Observed patch time UTC |
| --- | --- | --- |
| Initial dataset freeze | `96339d023f82d3e04958e3e5c1b6b404b9462ecd68d0f3807c5bba48e01f9f75` | 07:45:40 |
| Commit 1c6a64c | `788c5924da79cabcf63ea16c4a34048871d5a2af200e953bc2b6b69c0757e9d4` | 07:56:54 |
| Qwen, Fable and Codex run manifest | `c83a80495043e69270b897531257919936bbd0dd788abbc1a34fadda7455fb8c` | 07:57:08 |
| SmolLM3 run manifest | `ff912f40938324295ddbe07cfa5cc4d7e461a12b5bc0788be323853f2052f718` | 08:00:49 |
| Commit 8421a60346096e11debce5aa4b47baa4bac74c3b, archived for future runs | `6bb90f27b10e58946687a55eeb81a517a3e090fb18f01dbceea28bb78e65cfb8` | 08:06:37 |

The `c83a...` to `ff912...` diff changes only OpenCode event error
classification, an equivalent capability expression, and its isolation audit.
The `ff912...` to subsequently saved `6bb90...` version changes only OpenCode
checks and metadata. Normalized Python syntax-tree comparisons found the
following functions identical across all four recovered states and `6bb90...`:
`_load_mlx`, `_mlx_stream`, `_new_native`, `_validate`, `_number`, `_redact`,
`_separate_thinking`, `_visible_so_far`, `_base`, `_identity`, `_generate_mlx`,
and `_generate_native`. The generic dispatch gained an OpenCode branch;
inspection shows the MLX and native Claude/Codex paths remain unchanged.

The three initial run manifests record a 07:57:29 UTC start, between creation
of `c83a...` and the next recorded source edit at 07:57:33. The Smol manifest
records an 08:01:06 start, between creation of `ff912...` and the next edit at
08:01:33. These timestamps are consistent with the recorded hashes. Python
imports the adapter before the runner hashes source files, however, so the
manifest hash alone does not prove which bytes were imported if an edit occurs
in that interval. Future runs should use an immutable source snapshot.
